"""
hybrid_tflite.py — Suy luận mô hình lai PMG–Transformer (Thuật toán 2.1) bằng TFLite.

Thư mục mô hình (xuất từ notebook 03) gồm:
    hybrid_config.json
    <variant>/transformer_42.tflite, transformer_777.tflite,
              pmg_42.tflite, pmg_123.tflite, pmg_2026.tflite
"""
import json
import time
from pathlib import Path

import numpy as np

import features_np as F


def _make_interpreter(path, num_threads):
    try:
        from ai_edge_litert.interpreter import Interpreter          # gói mới (LiteRT)
    except ImportError:
        try:
            from tflite_runtime.interpreter import Interpreter      # gói cũ
        except ImportError:
            import tensorflow as tf                                 # đủ TensorFlow
            Interpreter = tf.lite.Interpreter
    it = Interpreter(model_path=str(path), num_threads=num_threads)
    it.allocate_tensors()
    return it


class _Sub:
    """Một mạng con TFLite; ánh xạ tên đầu vào (pose/motion/geometry/angles/skeleton_sequence)."""

    def __init__(self, path, num_threads):
        self.it = _make_interpreter(path, num_threads)
        self.inputs = []
        for d in self.it.get_input_details():
            name = d['name'].replace('serving_default_', '').split(':')[0]
            self.inputs.append((name, d['index']))
        self.out = self.it.get_output_details()[0]['index']

    def __call__(self, feeds):
        for name, idx in self.inputs:
            self.it.set_tensor(idx, feeds[name])
        self.it.invoke()
        return float(self.it.get_tensor(self.out).reshape(-1)[0])


class HybridFallModel:
    def __init__(self, model_dir, variant='float32', num_threads=4):
        model_dir = Path(model_dir)
        self.cfg = json.load(open(model_dir / 'hybrid_config.json'))
        vdir = model_dir / variant
        self.alpha = float(self.cfg['alpha_pmg'])
        self.tau = float(self.cfg['threshold_tau'])
        self.lam_tf = np.asarray(self.cfg['lambda_transformer'], float)
        self.lam_pmg = np.asarray(self.cfg['lambda_pmg'], float)
        self.tf_seeds = self.cfg['transformer_seeds']
        self.pmg_seeds = self.cfg['pmg_seeds']
        self.tta_tf = self.cfg['tta_transformer']
        self.tta_pmg = self.cfg['tta_pmg']
        self.tf_models = [_Sub(vdir / f'transformer_{s}.tflite', num_threads) for s in self.tf_seeds]
        self.pmg_models = [_Sub(vdir / f'pmg_{s}.tflite', num_threads) for s in self.pmg_seeds]
        self.last_timing = {}

    @staticmethod
    def _need_mirror(choice):
        return choice['mode'] != 'raw' and float(choice['beta']) > 0.0

    def predict(self, window):
        """window: (30, 51) float32 đã chuẩn hóa theo (1.7). Trả về p (xác suất Fall)."""
        t0 = time.perf_counter()
        X = np.asarray(window, np.float32).reshape(1, F.SEQ_LEN, F.NUM_FEATURES)
        need_m = any(self._need_mirror(self.tta_tf[str(s)]) for s in self.tf_seeds) or \
                 any(self._need_mirror(self.tta_pmg[str(s)]) for s in self.pmg_seeds)
        Xm = F.mirror_skeleton_sequence(X) if need_m else None
        P, M, G, A = F.build_features(X)
        feeds = {'skeleton_sequence': X, 'pose': P, 'motion': M, 'geometry': G, 'angles': A}
        if need_m:
            Pm, Mm, Gm, Am = F.build_features(Xm)
            feeds_m = {'skeleton_sequence': Xm, 'pose': Pm, 'motion': Mm, 'geometry': Gm, 'angles': Am}
        t1 = time.perf_counter()

        p_tf_list = []
        for s, m in zip(self.tf_seeds, self.tf_models):
            c = self.tta_tf[str(s)]
            raw = m(feeds)
            mir = m(feeds_m) if self._need_mirror(c) else raw
            p_tf_list.append(F.tta_blend(raw, mir, c['beta'], c['mode']))
        t2 = time.perf_counter()

        p_pmg_list = []
        for s, m in zip(self.pmg_seeds, self.pmg_models):
            c = self.tta_pmg[str(s)]
            raw = m(feeds)
            mir = m(feeds_m) if self._need_mirror(c) else raw
            p_pmg_list.append(F.tta_blend(raw, mir, c['beta'], c['mode']))
        t3 = time.perf_counter()

        p_tf = float(np.average(np.asarray(p_tf_list, float).ravel(), weights=self.lam_tf))
        p_pmg = float(np.average(np.asarray(p_pmg_list, float).ravel(), weights=self.lam_pmg))
        p = float(F.fuse_logit(p_tf, p_pmg, self.alpha))
        t4 = time.perf_counter()
        self.last_timing = {
            'features_ms': 1e3 * (t1 - t0), 'transformer_branch_ms': 1e3 * (t2 - t1),
            'pmg_branch_ms': 1e3 * (t3 - t2), 'fusion_ms': 1e3 * (t4 - t3), 'total_ms': 1e3 * (t4 - t0),
        }
        return p
