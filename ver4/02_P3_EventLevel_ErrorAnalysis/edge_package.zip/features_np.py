"""
features_np.py — Bản NumPy của các hàm tiền xử lý đặc trưng trong KLTN_EXP_099.

Dùng chung cho:
  * 03_P4_TFLite_convert.ipynb (kiểm tra TFLite trên Kaggle/PC)
  * realtime_pipeline.py và benchmark_tflite.py (chạy trên thiết bị, không cần TensorFlow đầy đủ)

Các hàm ở đây sao chép ĐÚNG logic của:
  * _mirror_skeleton_gpu()  (cell 4 của notebook EXP_099)
  * _build_features_gpu()   (cell 5 của notebook EXP_099)
Notebook 03 có ô kiểm tra so sánh với bản TensorFlow (sai lệch phải < 1e-4).
"""
import numpy as np

SEQ_LEN = 30
NUM_KP = 17
NUM_FEATURES = 51

# Thứ tự 17 khớp trong dữ liệu (đúng theo mã nguồn):
# 0 mũi | 1/2 vai T/P | 3/4 khuỷu T/P | 5/6 cổ tay T/P | 7/8 hông T/P
# 9/10 gối T/P | 11/12 cổ chân T/P | 13/14 gót chân T/P | 15/16 mũi bàn chân T/P
# Chỉ số tương ứng trong 33 điểm của MediaPipe Pose:
MEDIAPIPE_INDICES = [0, 11, 12, 13, 14, 15, 16, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32]
LR_SWAP = np.array([0, 2, 1, 4, 3, 6, 5, 8, 7, 10, 9, 12, 11, 14, 13, 16, 15], dtype=np.int64)


def mirror_skeleton_sequence(X):
    """Phản chiếu trái/phải quanh trục dọc qua tâm hông. X: (N, 30, 51) -> (N, 30, 51)."""
    X = np.asarray(X, dtype=np.float32)
    sk = X.reshape(-1, SEQ_LEN, NUM_KP, 3)
    hip_cx = (sk[:, :, 7, 0] + sk[:, :, 8, 0]) / 2.0
    mx = 2.0 * hip_cx[:, :, None] - sk[:, :, :, 0]
    sk = np.concatenate([mx[..., None], sk[:, :, :, 1:3]], axis=-1)
    sk = sk[:, :, LR_SWAP, :]
    return sk.reshape(-1, SEQ_LEN, NUM_FEATURES).astype(np.float32)


def _angle_3pts(a, b, c, eps=1e-6):
    ba = a - b
    bc = c - b
    dot = np.sum(ba * bc, axis=-1)
    den = np.linalg.norm(ba, axis=-1) * np.linalg.norm(bc, axis=-1)
    cosv = np.clip(dot / np.maximum(den, eps), -1.0, 1.0)
    return np.arccos(cosv)


def _first_difference(v):
    return np.concatenate([np.zeros_like(v[:, :1]), v[:, 1:] - v[:, :-1]], axis=1)


def build_features(X):
    """
    X: (N, 30, 51) đã chuẩn hóa theo (1.7).
    Trả về (pose (N,30,51), motion (N,30,68), geometry (N,30,21), angles (N,30,8)), float32.
    """
    X = np.asarray(X, dtype=np.float32)
    n = X.shape[0]
    sk = X.reshape(n, SEQ_LEN, NUM_KP, 3)
    xy = sk[..., :2]
    pose = X

    vel = np.concatenate([np.zeros_like(xy[:, :1]), xy[:, 1:] - xy[:, :-1]], axis=1)
    acc = np.concatenate([np.zeros_like(vel[:, :1]), vel[:, 1:] - vel[:, :-1]], axis=1)
    motion = np.concatenate([vel.reshape(n, SEQ_LEN, 34), acc.reshape(n, SEQ_LEN, 34)], axis=-1)

    l_sh, r_sh = xy[:, :, 1], xy[:, :, 2]
    l_hip, r_hip = xy[:, :, 7], xy[:, :, 8]
    l_knee, r_knee = xy[:, :, 9], xy[:, :, 10]
    l_ank, r_ank = xy[:, :, 11], xy[:, :, 12]
    sh_mid = (l_sh + r_sh) / 2.0
    hip_mid = (l_hip + r_hip) / 2.0

    x_all, y_all = xy[..., 0], xy[..., 1]
    body_width = x_all.max(axis=2) - x_all.min(axis=2)
    body_height = y_all.max(axis=2) - y_all.min(axis=2)
    aspect = body_width / np.maximum(body_height, 1e-6)
    shoulder_width = np.linalg.norm(l_sh - r_sh, axis=-1)
    hip_width = np.linalg.norm(l_hip - r_hip, axis=-1)
    torso_vec = sh_mid - hip_mid
    torso_len = np.linalg.norm(torso_vec, axis=-1)
    torso_angle = np.arctan2(np.abs(torso_vec[..., 0]), np.abs(torso_vec[..., 1]) + 1e-6)  # radian
    left_knee = _angle_3pts(l_hip, l_knee, l_ank)
    right_knee = _angle_3pts(r_hip, r_knee, r_ank)
    geometry_base = np.stack([body_width, body_height, aspect, shoulder_width, hip_width,
                              torso_len, torso_angle, left_knee, right_knee], axis=-1)

    speed = np.linalg.norm(vel, axis=-1)
    accel_mag = np.linalg.norm(acc, axis=-1)
    mean_speed = speed.mean(axis=2)
    max_speed = speed.max(axis=2)
    mean_accel = accel_mag.mean(axis=2)
    max_accel = accel_mag.max(axis=2)
    lower_extension = (np.linalg.norm(l_hip - l_ank, axis=-1) + np.linalg.norm(r_hip - r_ank, axis=-1)) / 2.0
    d_torso_angle = _first_difference(torso_angle)
    transition = np.stack([
        d_torso_angle, np.abs(d_torso_angle), _first_difference(aspect),
        _first_difference(body_height), lower_extension, _first_difference(lower_extension),
        mean_speed, max_speed, mean_accel, max_accel,
        _first_difference(mean_speed), _first_difference(torso_len),
    ], axis=-1)
    geometry = np.concatenate([geometry_base, transition], axis=-1)

    angles = np.stack([
        np.cos(_angle_3pts(l_sh, xy[:, :, 3], xy[:, :, 5])),
        np.cos(_angle_3pts(r_sh, xy[:, :, 4], xy[:, :, 6])),
        np.cos(_angle_3pts(xy[:, :, 3], l_sh, l_hip)),
        np.cos(_angle_3pts(xy[:, :, 4], r_sh, r_hip)),
        np.cos(_angle_3pts(l_sh, l_hip, l_knee)),
        np.cos(_angle_3pts(r_sh, r_hip, r_knee)),
        np.cos(_angle_3pts(l_hip, l_knee, l_ank)),
        np.cos(_angle_3pts(r_hip, r_knee, r_ank)),
    ], axis=-1)

    f32 = lambda a: np.asarray(a, dtype=np.float32)
    return f32(pose), f32(motion), f32(geometry), f32(angles)


def torso_angle_deg_last(X, n_theta=5):
    """θ̄_j (độ): trung bình góc nghiêng thân (2.6) trên n_theta khung cuối của mỗi cửa sổ."""
    sk = np.asarray(X, dtype=np.float32).reshape(-1, SEQ_LEN, NUM_KP, 3)
    sh_mid = (sk[:, :, 1, :2] + sk[:, :, 2, :2]) / 2.0
    hip_mid = (sk[:, :, 7, :2] + sk[:, :, 8, :2]) / 2.0
    v = sh_mid - hip_mid
    theta = np.degrees(np.arctan2(np.abs(v[..., 0]), np.abs(v[..., 1]) + 1e-6))
    return theta[:, -n_theta:].mean(axis=1)


# ---------------------------------------------------------------------
# Kết hợp dự đoán của mô hình lai: TTA (2.7a), trung bình λ (2.7), hợp nhất logit (2.8)
# ---------------------------------------------------------------------
def logit(p, eps=1e-6):
    p = np.clip(np.asarray(p, dtype=np.float64), eps, 1.0 - eps)
    return np.log(p / (1.0 - p))


def sigmoid(z):
    z = np.clip(z, -40, 40)
    return 1.0 / (1.0 + np.exp(-z))


def tta_blend(raw_prob, mirror_prob, beta, mode):
    beta = float(beta)
    raw_prob = np.asarray(raw_prob, dtype=np.float64)
    if mode == 'raw' or beta <= 0.0:
        return raw_prob
    mirror_prob = np.asarray(mirror_prob, dtype=np.float64)
    if mode == 'prob':
        return (1.0 - beta) * raw_prob + beta * mirror_prob
    if mode == 'logit':
        return sigmoid((1.0 - beta) * logit(raw_prob) + beta * logit(mirror_prob))
    raise ValueError(mode)


def fuse_logit(p_tf, p_pmg, alpha):
    return sigmoid((1.0 - alpha) * logit(p_tf) + alpha * logit(p_pmg))
