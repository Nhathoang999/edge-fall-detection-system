"""
alert_manager.py — Thuật toán 2.2: Bộ quản lý cảnh báo bốn trạng thái.

Dùng CHUNG một mã cho:
  * đánh giá phát lại trên UP-Fall (Thuật toán 3.1, notebook 02)
  * hệ thống chạy thời gian thực trên thiết bị (realtime_pipeline.py)

Trạng thái: NORMAL (BÌNH_THƯỜNG) -> SUSPECT (NGHI_NGỜ) -> CONFIRMED (XÁC_NHẬN) -> COOLDOWN (CHỜ)
"""
from dataclasses import dataclass, field

NORMAL, SUSPECT, CONFIRMED, COOLDOWN = 'NORMAL', 'SUSPECT', 'CONFIRMED', 'COOLDOWN'


@dataclass
class AlertParams:
    tau: float                 # ngưỡng phân loại τ
    theta_lie: float = 60.0    # ngưỡng góc nằm θ_lie (độ); 0 = bỏ bước xác nhận tư thế
    t_post: float = 3.0        # T_post (giây): thời gian tối đa chờ xác nhận
    t_cool: float = 30.0       # T_c (giây): thời gian chờ sau mỗi cảnh báo


@dataclass
class AlertManager:
    params: AlertParams
    state: str = NORMAL
    t_s: float = 0.0           # thời điểm bắt đầu nghi ngờ
    p_s: float = 0.0           # xác suất lúc bắt đầu nghi ngờ
    t_alert: float = float('-inf')
    alerts: list = field(default_factory=list)   # danh sách (t_alert, p_s)

    def reset(self):
        self.state = NORMAL
        self.t_s = 0.0
        self.p_s = 0.0
        self.t_alert = float('-inf')
        self.alerts = []

    def update(self, t_j, p_j, theta_j):
        """
        Xử lý một cửa sổ mới (bước 2 của Thuật toán 2.2).
        t_j: thời điểm kết thúc cửa sổ (giây); p_j: xác suất Fall; theta_j: θ̄_j (độ).
        Trả về True nếu phát cảnh báo tại cửa sổ này.
        """
        P = self.params
        # 2.1
        if self.state == COOLDOWN and (t_j - self.t_alert) >= P.t_cool:
            self.state = NORMAL
        # 2.2
        if self.state == NORMAL and p_j >= P.tau:
            self.state = SUSPECT
            self.t_s = t_j
            self.p_s = p_j
        # 2.3
        if self.state == SUSPECT:
            if theta_j >= P.theta_lie:
                self.state = CONFIRMED
            elif (t_j - self.t_s) > P.t_post:
                self.state = NORMAL
        # 2.4
        if self.state == CONFIRMED:
            self.t_alert = t_j
            self.alerts.append((t_j, self.p_s))
            self.state = COOLDOWN
            return True
        return False


def run_alert_manager(times, probs, thetas, params):
    """Chạy Thuật toán 2.2 trên một dãy cửa sổ đã sắp theo thời gian; trả về danh sách cảnh báo."""
    am = AlertManager(params)
    for t, p, th in zip(times, probs, thetas):
        am.update(float(t), float(p), float(th))
    return am.alerts


def run_every_window(times, probs, tau):
    """Chính sách so sánh: mỗi cửa sổ có p >= τ là một cảnh báo."""
    return [(float(t), float(p)) for t, p in zip(times, probs) if p >= tau]
