UP-Fall local deployment bundle
Model: Transformer baseline
Input: (30,51) float32
Threshold: 0.9500000000000002

Use the .tflite file for lightweight local inference.
Use .keras if you want TensorFlow/Keras inference or further fine-tuning.

IMPORTANT:
For raw webcam/video, reproduce the exact preprocessing used for the NPZ:
MediaPipe -> 17 keypoints -> interpolation -> exact normalize_skeleton()
-> rolling 30-frame buffer -> model -> threshold.
