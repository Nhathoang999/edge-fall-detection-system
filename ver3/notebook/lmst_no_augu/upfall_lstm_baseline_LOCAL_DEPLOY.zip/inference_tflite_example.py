import json
import numpy as np
import tensorflow as tf
from pathlib import Path

HERE = Path(__file__).resolve().parent
cfg = json.load(open(HERE / "deployment_config.json", "r", encoding="utf-8"))
threshold = float(cfg["threshold"])

model_path = next(HERE.glob("*.tflite"))
interpreter = tf.lite.Interpreter(model_path=str(model_path))
interpreter.allocate_tensors()

inp = interpreter.get_input_details()[0]
out = interpreter.get_output_details()[0]

def predict_preprocessed(sequence_30x51):
    x = np.asarray(sequence_30x51, dtype=np.float32)
    if x.shape != (30, 51):
        raise ValueError(f"Expected (30,51), got {x.shape}")
    interpreter.set_tensor(inp["index"], x[None, ...])
    interpreter.invoke()
    prob = float(interpreter.get_tensor(out["index"]).reshape(-1)[0])
    label = int(prob >= threshold)
    return {
        "prob_fall": prob,
        "label": label,
        "class_name": "Fall" if label else "No Fall",
    }
